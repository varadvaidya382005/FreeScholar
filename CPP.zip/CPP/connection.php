<?php
$conn = mysqli_connect("localhost", "root", "", "capstone_project");
?>